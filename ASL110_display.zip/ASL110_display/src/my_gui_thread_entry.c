//-------------------------------------------------------------------------
#include "my_gui_thread.h"
#include "lcd.h"
#include <my_gui_thread_entry.h>
#include <stdio.h>
#include "gx_api.h"
#include "my_guix_resources.h"
#include "my_guix_specifications.h"

//-------------------------------------------------------------------------
GX_CHAR version_string[16]     = "Version: 0.0.1";
GX_CHAR version_string2[20] = "Attendant: V0.0.1";
GX_CHAR version_string3[10]     		 	=  "V0.0.1";

//-------------------------------------------------------------------------
extern GX_PROMPT * time_infor_pmpt_text;

//-------------------------------------------------------------------------
GX_WINDOW_ROOT * p_window_root;
GX_PROMPT * firmware_ver_text = &init_screen.init_screen_InitPrmpt2;
GX_PROMPT * first_pmpt_text = &init_screen.init_screen_InitPrmpt3;


void my_gui_thread_entry(void);

static void guix_test_send_touch_message(sf_touch_panel_payload_t * p_payload);

static void reset_check(void);

//-------------------------------------------------------------------------
void  g_timer0_callback(timer_callback_args_t * p_args) //25ms
{
  (void)p_args;


  if(Shut_down_display_timeout != 0) Shut_down_display_timeout--;

  if(Shut_down_display_timeout2 != 0) Shut_down_display_timeout2--;

  if(chk_status_timeout != 0) chk_status_timeout--;

  if(LongHoldtmr != 0) LongHoldtmr--;

  if(chk_date_time_timeout != 0) chk_date_time_timeout--;

  if(chk_screen_chg_timeout != 0) chk_screen_chg_timeout--;
  
}

//-------------------------------------------------------------------------
void  g_timer1_callback(timer_callback_args_t * p_args) //1612us
{
  (void)p_args;


  if(beep_level == IOPORT_LEVEL_LOW) beep_level = IOPORT_LEVEL_HIGH;
  else beep_level = IOPORT_LEVEL_LOW;

  g_ioport.p_api->pinWrite(beep_out, beep_level);
  
}

//-------------------------------------------------------------------------
void  g_timer2_callback(timer_callback_args_t * p_args) //819us
{
  (void)p_args;


  if(beep_level == IOPORT_LEVEL_LOW) beep_level = IOPORT_LEVEL_HIGH;
  else beep_level = IOPORT_LEVEL_LOW;

  g_ioport.p_api->pinWrite(beep_out, beep_level);
  
}

//-------------------------------------------------------------------------
void g_lcd_spi_callback(spi_callback_args_t * p_args)
{
  if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE) 
    tx_semaphore_ceiling_put(&g_my_gui_semaphore, 1);
    
}

//-------------------------------------------------------------------------
uint8_t eprm_read(uint16_t addr)	//need 163us?
{
  uint8_t i, data;
  uint16_t addr_temp;
  ioport_level_t pin_state;
  
  
  addr_temp = addr&0x00ff;
  if(addr&0x0100) addr_temp |= 0x0b00; 
  else addr_temp |= 0x0300;
  
  g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);
  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_LOW);
  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
  
  //send address
  for(i = 0; i < 16; i++) {
    if( addr_temp&0x8000 ) {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_HIGH);//output_high(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);    
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //delay_us(1);
    }
    else {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_LOW);//output_low(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    
    addr_temp = (uint16_t)(addr_temp<<1);
    
  }
	
	//read data
	data = 0;
  for(i = 0; i < 8; i++) {
    //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    g_ioport_on_ioport.pinRead(eprm_out, &pin_state); 
    if(pin_state == IOPORT_LEVEL_HIGH) data = (uint8_t)( (data<<1)|0x01 );
    else data = (uint8_t)( (data<<1)&0xfe );
    g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
    R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
    R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    
  }
  
  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);//output_high(eprm_sel);
	
  return data;
	
}
//-------------------------------------------------------------------------
uint8_t eprm_write(uint16_t addr, uint8_t value)	//need 2.72ms?
{
  uint8_t i, data, wait;
  uint16_t addr_temp;
  ioport_level_t pin_state;
  
  
//  output_low(PIN_B7);
  
  addr_temp = addr&0x00ff;
  if(addr&0x0100) addr_temp |= 0x0a00; 
  else addr_temp |= 0x0200;
  
  g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_LOW);//output_low(eprm_sel);
  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);

  //send Write Enable
  data = 0x06;
  for(i = 0; i < 8; i++) {
    if( data&0x80 ) {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_HIGH);//output_high(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);    
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    else {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_LOW);//output_low(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    
    data = (uint8_t)(data<<1);
    
  }

  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);//output_high(eprm_sel);
  R_BSP_SoftwareDelay(3,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(3);

  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_LOW);//output_low(eprm_sel);
  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
  
  //send address
  for(i = 0; i < 16; i++) {
    if( addr_temp&0x8000 ) {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_HIGH);//output_high(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);    
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    else {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_LOW);//output_low(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    
    addr_temp = (uint16_t)(addr_temp<<1);
    
  }
	
	//send value
	for(i = 0; i < 8; i++) {
    if( value&0x80 ) {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_HIGH);//output_high(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);    
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    else {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_LOW);//output_low(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    
    value = (uint8_t)(value<<1);
    
  }

  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);//output_high(eprm_sel);
	
	//read Status Register
  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_LOW);//output_low(eprm_sel);
  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
  
  //send instruction
  data = 0x05;
  for(i = 0; i < 8; i++) {
    if( data&0x80 ) {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_HIGH);//output_high(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);    
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    else {
      g_ioport.p_api->pinWrite(eprm_in, IOPORT_LEVEL_LOW);//output_low(eprm_in);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
      R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
      g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
      //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
    }
    
    data = (uint8_t)(data<<1);
    
  }
	
  wait = 90; //waiting time //max: about 5ms 
  do {	
  	//read data
  	data = 0;
    for(i = 0; i < 8; i++) {
  	  //R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1); 
  	  g_ioport_on_ioport.pinRead(eprm_out, &pin_state); 
    	if(pin_state == IOPORT_LEVEL_HIGH) data = (uint8_t)( (data<<1)|0x01 );
    	else data = (uint8_t)( (data<<1)&0xfe );
    	
  	  g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_HIGH);//output_high(eprm_clk);
  	  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
  	  g_ioport.p_api->pinWrite(eprm_clk, IOPORT_LEVEL_LOW);//output_low(eprm_clk);
  	  R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MICROSECONDS);//delay_us(1);
  	  
  	}
  	
  	wait--;
    if(wait == 0) break; //time out
      
	}while(data&0x01);	//nomally 'wait' is change to 39


  g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);//output_high(eprm_sel);
	
	if(wait == 0) {
	//	eeprm_w_err++;
		return 1;						//err happenned
	}
	else return 0;
	
//	output_high(PIN_B7);
	
}

//-------------------------------------------------------------------------
void init_rtcc(void)
{
	ssp_err_t err;
	
	
	rtcc_data[8] = 0;	//addr0 for reading ST
	g_i2c1.p_api->write(g_i2c1.p_ctrl, &rtcc_data[8], 1, true);

	err = g_i2c1.p_api->read(g_i2c1.p_ctrl, rtcc_data, 1, false);
  if(SSP_SUCCESS != err)
  {
      g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
  }
  
  if( (rtcc_data[0]&0x80) != 0x80 ) { //ST = 0
		rtcc_data[0] = 0; 		//addr0
		rtcc_data[1] = 0x81; 	//Data to TIMEKEEPING SECONDS VALUE REGISTER
		rtcc_data[2] = 0x01;
		rtcc_data[3] = 0x41; 	//set to 12 Hour Time Format
		rtcc_data[4] = 0x09;	//External Battery Backup Supply (VBAT) Enable
		rtcc_data[5] = 0x01;
		rtcc_data[6] = 0x01;
		rtcc_data[7] = 0x17;
		rtcc_data[8] = 0x80; 	//CONTROL REGISTER
		rtcc_data[9] = 80;		//OSCILLATOR DIGITAL TRIM REGISTER
		
		err = g_i2c1.p_api->write(g_i2c1.p_ctrl, rtcc_data, 10, false);
  	if(SSP_SUCCESS != err)
  	{
  	   g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
  	}
  	
  }  

}

//-------------------------------------------------------------------------
void read_rtcc(void)
{
	ssp_err_t err;
	
	
	rtcc_data[0] = 0;	//addr0
	g_i2c1.p_api->write(g_i2c1.p_ctrl, &rtcc_data[0], 1, true);

	err = g_i2c1.p_api->read(g_i2c1.p_ctrl, &rtcc_data[1], 7, false);
  if(SSP_SUCCESS != err)
  {
      g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
  }
  
}

//-------------------------------------------------------------------------
void write_rtcc(void)
{
	ssp_err_t err;
	
  
	rtcc_data[0] = 0; //addr0
	err = g_i2c1.p_api->write(g_i2c1.p_ctrl, rtcc_data, 8, false);
  if(SSP_SUCCESS != err)
  {
     g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
  }
  	
}

//-------------------------------------------------------------------------

/*********************************************************************************************************************
 * @brief  Sends a touch event to GUIX internal thread to call the GUIX event handler function
 *
 * @param[in] p_payload Touch panel message payload
***********************************************************************************************************************/
static void guix_test_send_touch_message(sf_touch_panel_payload_t * p_payload)
{
    bool send_event = true;
    GX_EVENT gxe;
		GX_VALUE x_num;	//, y_num;
		

    switch (p_payload->event_type)
    {
    case SF_TOUCH_PANEL_EVENT_DOWN:
        gxe.gx_event_type = GX_EVENT_PEN_DOWN;
        break;
    case SF_TOUCH_PANEL_EVENT_UP:
        gxe.gx_event_type = GX_EVENT_PEN_UP;
        break;
    case SF_TOUCH_PANEL_EVENT_HOLD:
    case SF_TOUCH_PANEL_EVENT_MOVE:
        gxe.gx_event_type = GX_EVENT_PEN_DRAG;
        break;
    case SF_TOUCH_PANEL_EVENT_INVALID:
        send_event = false;
        break;
    default:
        break;
    }

    if (send_event)
    {
        /** Send event to GUI */
        gxe.gx_event_sender         = GX_ID_NONE;
        gxe.gx_event_target         = 0;  /* the event to be routed to the widget that has input focus */
        gxe.gx_event_display_handle = 0;

        gxe.gx_event_payload.gx_event_pointdata.gx_point_x = (GX_VALUE)(p_payload->y);//y_num;
        
        x_num = (GX_VALUE)(240 - p_payload->x);

        if(x_num < 140) {
           if(x_num < 5) x_num = 0;
           else if(x_num < 10) x_num = (GX_VALUE)(x_num - 5);
           else if(x_num < 20) x_num = (GX_VALUE)(x_num - 9);
           else if(x_num < 40) x_num = (GX_VALUE)(x_num - 19);
           else if(x_num < 50) x_num = (GX_VALUE)(x_num - 32);
           else if(x_num < 70) x_num = (GX_VALUE)(x_num - 30);
           else if(x_num < 90) x_num = (GX_VALUE)(x_num - 25);
           else if(x_num < 110) x_num = (GX_VALUE)(x_num -20);
           else if(x_num < 120) x_num = (GX_VALUE)(x_num -15);
           else x_num = (GX_VALUE)(x_num - 12);
        }
        if(x_num > 190) {
        	x_num = (GX_VALUE)(x_num + 10);
        	if(x_num > 240) x_num = 240;
        }

        gxe.gx_event_payload.gx_event_pointdata.gx_point_y = x_num;

        gx_system_event_send(&gxe);
    }
}
//-------------------------------------------------------------------------
void update_display(void)
{
    ssp_err_t err;

    sf_message_header_t * p_message = NULL;

    GX_EVENT gxe;


    gxe.gx_event_sender = GX_ID_NONE;

    gxe.gx_event_target = 0;

    gxe.gx_event_display_handle = 0;

    gxe.gx_event_type = UPDATE_DISPLAY_EVENT;

    gx_system_event_send(&gxe);
    
   	
    err = g_sf_message0.p_api->pend(g_sf_message0.p_ctrl, &my_gui_thread_message_queue, (sf_message_header_t **) &p_message, 10); //TX_WAIT_FOREVER); //
    if(!err) {
        switch (p_message->event_b.class_code)
        {
            case SF_MESSAGE_EVENT_CLASS_TOUCH:
                if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
                {
                    //sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                    /** Translate a touch event into a GUIX event */
                    guix_test_send_touch_message((sf_touch_panel_payload_t *) p_message);
                }
                break;

            default:
                break;
        }

        /** Message is processed, so release buffer. */
        err = g_sf_message0.p_api->bufferRelease(g_sf_message0.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
        if (err)
        {
        		g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
        }

    }

}

//-------------------------------------------------------------------------
void show_info_scrn(void)
{
    ssp_err_t err;

    sf_message_header_t * p_message = NULL;

    GX_EVENT gxe;


    gxe.gx_event_sender = GX_ID_NONE;

    gxe.gx_event_target = 0;

    gxe.gx_event_display_handle = 0;

    gxe.gx_event_type = Display_Information_Screen;

    gx_system_event_send(&gxe);
   
    err = g_sf_message0.p_api->pend(g_sf_message0.p_ctrl, &my_gui_thread_message_queue, (sf_message_header_t **) &p_message, 10); //TX_WAIT_FOREVER);
    if(!err) {
        switch (p_message->event_b.class_code)
        {
            case SF_MESSAGE_EVENT_CLASS_TOUCH:
                if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
                {
                    //sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                    // Translate a touch event into a GUIX event 
                    guix_test_send_touch_message((sf_touch_panel_payload_t *) p_message);
                }
                break;

            default:
                break;
        }

        // Message is processed, so release buffer.
        err = g_sf_message0.p_api->bufferRelease(g_sf_message0.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
        if (err)
        {
        		g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
        }
				
    }

}
//-------------------------------------------------------------------------
void return_info_scrn(void)
{
    ssp_err_t err;

    sf_message_header_t * p_message = NULL;

    GX_EVENT gxe;


    gxe.gx_event_sender = GX_ID_NONE;

    gxe.gx_event_target = 0;

    gxe.gx_event_display_handle = 0;

    gxe.gx_event_type = Return_InforScr_Event;

    gx_system_event_send(&gxe);
   
    err = g_sf_message0.p_api->pend(g_sf_message0.p_ctrl, &my_gui_thread_message_queue, (sf_message_header_t **) &p_message, 10); //TX_WAIT_FOREVER);
    if(!err) {
        switch (p_message->event_b.class_code)
        {
            case SF_MESSAGE_EVENT_CLASS_TOUCH:
                if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
                {
                    //sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                    // Translate a touch event into a GUIX event 
                    guix_test_send_touch_message((sf_touch_panel_payload_t *) p_message);
                }
                break;

            default:
                break;
        }

        // Message is processed, so release buffer.
        err = g_sf_message0.p_api->bufferRelease(g_sf_message0.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
        if (err)
        {
        		g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
        }
				
    }

}
//-------------------------------------------------------------------------
static void reset_check(void) 
{
	UINT status = TX_SUCCESS;
	
   
  switch(get_sw()) {
    case sw_fwd_rev: 
    		status = gx_prompt_text_set(first_pmpt_text, "Reset Device");
				if (GX_SUCCESS != status)
    		{
    			g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    		}
    		
    		update_display();
           
  			
  			R_BSP_SoftwareDelay(1500, BSP_DELAY_UNITS_MILLISECONDS);//delay_ms(1500);  
  			
  			//reset the System
        NVIC_SystemReset();
  			//can't come here  
        while(get_sw() == sw_fwd_rev);
        break;

    default:
    		R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);//delay_ms(100);
       	break;
  }

}

//-------------------------------------------------------------------------
/* Gui Test App Thread entry function */
void my_gui_thread_entry(void)
{
    ssp_err_t err;
    sf_message_header_t * p_message = NULL;
    UINT status = TX_SUCCESS;
    uint8_t i, test_num;
    int check_temp_num;
    
    
		//debug pins
    g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(TEST_PIN, IOPORT_LEVEL_LOW);
    
    g_ioport_on_ioport.pinWrite(i2c_cs, IOPORT_LEVEL_HIGH);
  	g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);
		g_ioport.p_api->pinWrite(beep_out, IOPORT_LEVEL_LOW);

    /* Initializes GUIX. */
    status = gx_system_initialize();
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    /* Initializes GUIX drivers. */
    err = g_sf_el_gx0.p_api->open (g_sf_el_gx0.p_ctrl, g_sf_el_gx0.p_cfg);
    if(SSP_SUCCESS != err)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    gx_studio_display_configure ( MAIN_DISPLAY,
                                  g_sf_el_gx0.p_api->setup,
                                  LANGUAGE_ENGLISH,
                                  MAIN_DISPLAY_THEME_1,
                                  &p_window_root );

    err = g_sf_el_gx0.p_api->canvasInit(g_sf_el_gx0.p_ctrl, p_window_root);
    if(SSP_SUCCESS != err)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    /* Create the widgets we have defined with the GUIX data structures and resources. */
    GX_WIDGET * p_first_screen = NULL;
    
		
		/* Create the screens. */
    gx_studio_named_widget_create("edit_screen", (GX_WIDGET *)p_window_root, &p_first_screen);

    gx_studio_named_widget_create("popup_screen2", (GX_WIDGET *)p_window_root, &p_first_screen);

    gx_studio_named_widget_create("DateTime_screen", (GX_WIDGET *)p_window_root, &p_first_screen);

    gx_studio_named_widget_create("popup_screen", (GX_WIDGET *)p_window_root, &p_first_screen);

  #ifdef using_keyboard   
    gx_studio_named_widget_create("keyboard_screen", (GX_WIDGET *)p_window_root, &p_first_screen);
	#endif
		
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
		
		status = gx_studio_named_widget_create("information_screen",
                                           (GX_WIDGET *)p_window_root, &p_first_screen);
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
    
    status = gx_studio_named_widget_create("init_screen",
                                           (GX_WIDGET *)p_window_root, &p_first_screen);
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
    
    /* Attach the first screen to the root so we can see it when the root is shown */
   gx_widget_attach(p_window_root, p_first_screen);

    /* Shows the root window to make it and patients screen visible. */
    status = gx_widget_show(p_window_root);
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    /* Lets GUIX run. */
    status = gx_system_start();
    if(TX_SUCCESS != status)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    gx_system_focus_claim(p_first_screen);

    /** Open the SPI driver to initialize the LCD **/
    err = g_rspi_lcdc.p_api->open(g_rspi_lcdc.p_ctrl, g_rspi_lcdc.p_cfg);
    if(SSP_SUCCESS != err)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    // Open the I2C driver for CLOCK 
    err = g_i2c1.p_api->open(g_i2c1.p_ctrl, g_i2c1.p_cfg);
    if(SSP_SUCCESS != err)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }

    // Open the ADC driver for Thermistor 
    err = g_adc0.p_api->open(g_adc0.p_ctrl, g_adc0.p_cfg);
    if(SSP_SUCCESS != err)
    {
        g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
		
		g_ioport.p_api->pinWrite(eprm_sel, IOPORT_LEVEL_HIGH);


    /** Setup the ILI9341V **/
    ILI9341V_Init();

		
		InitializeSys();

  	LCD_ON();
		
		chk_status_timeout = 14; //(14+2)*25 = 400ms
		//debug_timer0_flag = 0;
		err = g_timer0.p_api->open(g_timer0.p_ctrl, g_timer0.p_cfg);
		if (err != SSP_SUCCESS)
		{
			g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);	//Error
			
		}
		
		// version of firmware	
		status = gx_prompt_text_set(firmware_ver_text, version_string);
		if (GX_SUCCESS != status)
    {
    	g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
    
    status = gx_prompt_text_set(first_pmpt_text, "Init...");
		if (GX_SUCCESS != status)
    {
    	g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    }
    
    update_display();

		init_rtcc();
        
    //delay 4.5s	
    R_BSP_SoftwareDelay(4500, BSP_DELAY_UNITS_MILLISECONDS);
 	
    //Open WDT; 4.46s; PCLKB 30MHz
 	  g_wdt.p_api->open(g_wdt.p_ctrl, g_wdt.p_cfg);
		//Start the WDT by refreshing it
 	  g_wdt.p_api->refresh(g_wdt.p_ctrl);
  
  	i = 0;
  	do {
  		test_num = get_PROP_version();
  		
    	R_BSP_SoftwareDelay(30, BSP_DELAY_UNITS_MILLISECONDS);//delay_ms(30);  
    	//restart_wdt();
    	//Start the WDT by refreshing it
 	  	g_wdt.p_api->refresh(g_wdt.p_ctrl);
    	if(i > 5) break;
    	i++;
  	} while(test_num != 0);

  	if (i > 5) {
    	status = gx_prompt_text_set(first_pmpt_text, "Communication Fail");
			if (GX_SUCCESS != status)
    	{
    		g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
    	}
			
			update_display();
    
    	while(1) {
    		reset_check();
    	}
  	}
 	
		show_info_scrn();	

  	//beep
		beep_set(3, 300);
  	
  	Shut_down_display_timeout = shut_down_timer1;
  	
  	chk_status_timeout = 20;	//delay about 550ms
  	
 		check_temp_num = 0;
    
    //Open WDT; 4.46s; PCLKB 30MHz
 	//  g_wdt.p_api->open(g_wdt.p_ctrl, g_wdt.p_cfg);
		//Start the WDT by refreshing it
 	//  g_wdt.p_api->refresh(g_wdt.p_ctrl);

  	
  	chk_screen_chg_timeout = 16; //for Static Test
  						
    while(1)
    {

        err = g_sf_message0.p_api->pend(g_sf_message0.p_ctrl, &my_gui_thread_message_queue, (sf_message_header_t **) &p_message, 10); //TX_WAIT_FOREVER); //
        if(!err) {
            switch (p_message->event_b.class_code)
            {
                case SF_MESSAGE_EVENT_CLASS_TOUCH:
                    if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
                    {
                        //sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                        // Translate a touch event into a GUIX event 
                        guix_test_send_touch_message((sf_touch_panel_payload_t *) p_message);
                    }
                    break;

                default:
                    break;
            }

            //Message is processed, so release buffer.
            err = g_sf_message0.p_api->bufferRelease(g_sf_message0.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
            if (err)
                {
                    g_ioport.p_api->pinWrite(GRNLED, IOPORT_LEVEL_LOW);
                }

        }

        if( chk_status_timeout == 0 && LCD_off_flag == 0 ) { //adding LCD_off_flag check is for clear 'sigma_dat1_get' 
        
          get_PROP_version();//chk_sigma_status();
          chk_status_timeout = 20;	//delay about 550ms
          
          update_display();
        }
        
        if(LCD_off_flag == 1) main_menu();
        
        if(Shut_down_display_timeout == 0 && Shut_down_display_timeout2 == 0 && LCD_off_flag == 0) {
          BackLight(OFF);
          LCD_off_flag = 1;
        }
				
				//Check Date_Time
    		if(chk_date_time_timeout == 0) {
    			
    			if(page_information_screen_flag == 1) {
    				read_rtcc();
    				
						if( (rtcc_data[3]&0x20) == 0x20 ) sprintf(time_string, "%02x:%02x", rtcc_data[3]&0x1f, rtcc_data[2]);
        		else sprintf(time_string, "%02x:%02x", rtcc_data[3]&0x1f, rtcc_data[2]);
        	
    				gx_prompt_text_set(time_infor_pmpt_text, time_string);
    				
    				chk_date_time_timeout = 40;  //check every 1s
    				
    				update_display();
        	}   
  			
  				check_temp_num++;
  				if(check_temp_num > 10) {	//11s
  					check_temp_num = 0;
  				}
    		}
        
        //for Static Test
        if(page_information_screen_flag == 1 && chk_screen_chg_timeout == 0 && LCD_off_flag == 1) {	
        	chk_screen_chg_timeout = 64; //for Static Test
        	show_window((GX_WINDOW*)&information_screen, (GX_WIDGET*)&information_screen, false);
          chk_screen_chg_timeout = 32; //for Static Test
        }
        
			 	//Refresh WDT
 	  		g_wdt.p_api->refresh(g_wdt.p_ctrl);

    }
}

//-------------------------------------------------------------------------
